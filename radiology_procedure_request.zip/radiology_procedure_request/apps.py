from django.apps import AppConfig


class RadiologyProcedureRequestConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "radiology_procedure_request"
